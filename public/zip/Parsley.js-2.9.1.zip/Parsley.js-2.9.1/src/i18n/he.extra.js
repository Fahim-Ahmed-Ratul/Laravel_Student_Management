// Validation errors messages for Parsley
import Parsley from '../parsley';

Parsley.addMessages('he', {
  dateiso: "ערך זה צריך להיות תאריך בפורמט (YYYY-MM-DD)."
});
