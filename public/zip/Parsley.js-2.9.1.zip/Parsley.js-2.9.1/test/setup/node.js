import './node_setup'; // Import this before jquery is imported!
import setup from './setup';
setup();
